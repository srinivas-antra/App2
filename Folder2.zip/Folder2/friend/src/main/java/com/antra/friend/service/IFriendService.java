package com.antra.friend.service;

import java.util.List;

import com.antra.friend.entity.Friend;

public interface IFriendService {
	String  addFriendService(Friend friend);
	List<Long>  readFriendsContacts(Long phoneNumber);

}
