package com.antra.customer.service;

import com.antra.customer.model.CustomerDTO;
import com.antra.customer.model.LoginDTO;
import com.antra.customer.model.RegisterDTO;


public interface ICustomerService {
	
	boolean  registerCustomer(RegisterDTO  registerDto);
	
	boolean  loginCustomer(LoginDTO  loginDto);
	
	CustomerDTO  readCustomer(Long phoneNumber);
}
