package com.antra.customer.feign.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.antra.customer.model.PlanDTO;

@FeignClient(name="Plan", url="http://localhost:2122")
public interface PlanProxy {
	@GetMapping("/{planId}")
	public PlanDTO  fetchPlan(@PathVariable String planId);
}
