package com.antra.friend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendApplicationTests {

	@Test
	void contextLoads() {
	}

}
