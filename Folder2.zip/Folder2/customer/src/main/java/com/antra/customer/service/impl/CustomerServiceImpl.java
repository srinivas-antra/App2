package com.antra.customer.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.antra.customer.entity.Customer;
import com.antra.customer.model.CustomerDTO;
import com.antra.customer.model.LoginDTO;
import com.antra.customer.model.RegisterDTO;
import com.antra.customer.repsitory.CustomerRepository;
import com.antra.customer.service.ICustomerService;


@Service
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	CustomerRepository repository;

	@Override
	public boolean registerCustomer(RegisterDTO registerDto) {
		
		if(repository.existsById(registerDto.getPhoneNumber())==false) {
			Customer  customer=new Customer();
			BeanUtils.copyProperties(registerDto, customer);
			repository.save(customer);
			return true;
		}
		else {
			return  false;
		}
	}

	@Override
	public boolean loginCustomer(LoginDTO loginDto) {
		
		if(repository.checkLogin(loginDto.getPhoneNumber(), loginDto.getPassword())==1) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public CustomerDTO readCustomer(Long phoneNumber) {
		Customer customer = repository.findById(phoneNumber).get();
		CustomerDTO  customerDto=new CustomerDTO();
		BeanUtils.copyProperties(customer, customerDto);
		return customerDto;
	}

}
