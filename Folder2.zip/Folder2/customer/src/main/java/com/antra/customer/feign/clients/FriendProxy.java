package com.antra.customer.feign.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(name="Friend", url="http://localhost:2121")
@FeignClient(name="Friend")
public interface FriendProxy {
	
	@GetMapping("/{phoneNumber}")
	public List<Long> fetchFriends(@PathVariable Long phoneNumber);

}
