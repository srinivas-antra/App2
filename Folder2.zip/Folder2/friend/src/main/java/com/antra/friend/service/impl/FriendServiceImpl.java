package com.antra.friend.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.antra.friend.entity.Friend;
import com.antra.friend.repository.FriendRepository;
import com.antra.friend.service.IFriendService;



@Service
public class FriendServiceImpl implements IFriendService {
	@Autowired
	FriendRepository  repository;
	
	private static Logger logger = LoggerFactory.getLogger(FriendServiceImpl.class);

	@Override
	public String addFriendService(Friend friend) {
		
		Integer  count=repository.checkFriendContact(friend.getPhoneNumber(), friend.getFriendNumber());
		if(count==0) {
			repository.saveAndFlush(friend);
			logger.info("Friend entity is added the database successfully");
			return  "Friend contact is added";
		}
		else {
			logger.info("The friend number for a customer already exist");
			return "Friend contact already exist";
		}
	}

	@Override
	public List<Long> readFriendsContacts(Long phoneNumber) {
		
		return  repository.findFriendsContactNumbers(phoneNumber);
	}

}
