package com.antra.plan.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@RestController
@RequestMapping("/circuit")
public class CircuitBreakerController {
	
	private static Logger logger = LoggerFactory.getLogger(CircuitBreakerController.class);
	
	@GetMapping("/sample-api")
	//@Retry(name="sample-api", fallbackMethod = "defaultSampleApi")
	@CircuitBreaker(name="default", fallbackMethod = "defaultSampleApi")
	public String sampleApi() {
		logger.info("Request Call Received");
		String str = new RestTemplate().getForObject("http://localhost:1818/dummy", String.class);
		return str;
	}
	
	public String defaultSampleApi(Exception ex) {
		return "fallback-response";
	}

}
