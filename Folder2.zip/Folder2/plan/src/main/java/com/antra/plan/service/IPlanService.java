package com.antra.plan.service;

import java.util.List;

import com.antra.plan.model.PlanDTO;

public interface IPlanService {
	
	List<PlanDTO>  getAllPlans();
	
	PlanDTO   getSpecificPlan(String planId);

}
